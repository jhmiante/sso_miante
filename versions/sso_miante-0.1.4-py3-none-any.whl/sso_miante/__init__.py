default_app_config = "sso_miante.apps.SsoMianteConfig"
