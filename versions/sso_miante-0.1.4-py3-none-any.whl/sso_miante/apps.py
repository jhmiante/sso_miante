from django.apps import AppConfig

class SsoMianteConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "sso_miante"
    verbose_name = "SSO Miante"

