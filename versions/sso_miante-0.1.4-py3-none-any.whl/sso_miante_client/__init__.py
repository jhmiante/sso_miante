default_app_config = "sso_miante_client.apps.SsoMianteConfig"
